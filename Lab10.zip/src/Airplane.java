
public class Airplane extends Vehicle implements Warplane{
	private String flightNumber, company;
	Airplane()
	{
		 motor = "";
		 flightNumber = "";
		 company = "";
	}
	
	// ======================WAR PLAN FUNCTIONS =============
	
	public String getCountry()
	{
		return Warplane.country;
	}
	
	public void fireWeapon()
	{
		System.out.println("Warplane Weapon is Firing, Value is : "+ Warplane.weapon);
	}
	

//=========================================================

	public void setMotor(String x)
	{
		 motor = x;
	}
	public  String getMotor()
	{
		 return motor;
	}
	protected String getFlightNumber()
	{
		return flightNumber;
	}
	protected void setFlightNumber(String x)
	{
		flightNumber = x;
	}
	protected String getCompany()
	{
		return company;
	}
	protected void setCompany(String x)
	{
		company = x;
	}
}
