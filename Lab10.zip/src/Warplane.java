public interface Warplane 
{
	public String country = "NA";
	public String weapon = "Default Weapon";
	//public void setCountry(String c);
	public String getCountry();
	
	public void fireWeapon();
	
	//public void setWeapon(String w);
}