
public class Car extends Vehicle{
	private String licensePlate ;
	
	Car()
	{
		motor = "";
		licensePlate = "";
	}
	public void setMotor(String x)
	{
		 motor = x;
	}
	public  String getMotor()
	{
		 return motor;
	}
	
	protected String getLicense()
	{
		return licensePlate;
	}
	protected void setLicense(String x)
	{
		licensePlate = x;
	}
	
}
