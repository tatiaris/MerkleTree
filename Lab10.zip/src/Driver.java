
//Question 3 Lab 10: 
public class Driver{

	public static void main(String[] args) {	
		Car c = new Car();
		
		c.setLicense("licenseVAL");
		System.out.println("License After set: "+c.getLicense());
		
		c.setSpeed(3);
		System.out.println("Speed After set: "+c.getSpeed());
		
		c.setMotor("motor1");
		System.out.println("Motor After set: "+c.getMotor());
		System.out.println("==========FOR CAR===========");
		c.left();
		c.right();
		c.forward();
		c.reverse();
		
		
		Airplane a = new Airplane();
		
		a.setFlightNumber("flightnum");
		System.out.println("Flight Num: "+a.getFlightNumber());
		a.setCompany("flightCompany");
		System.out.println("flight Company value: "+a.getCompany());
		a.setSpeed(4);
		System.out.println("Speed After set: "+a.getSpeed());
		
		a.setMotor("motor2");
		System.out.println("Motor After set: "+a.getMotor());
		System.out.println("========FOR AIRPLANE========");
		a.left();
		a.right();
		a.forward();
		a.reverse();
		System.out.println("=============Question 4============");
		System.out.println("Warplane Country:"+a.getCountry());
		a.fireWeapon();
		
	}

}
