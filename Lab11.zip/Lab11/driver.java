//driver file

public class driver{

    public static void main(String [] args)
    {
        
        Address a = new Address("TX", "Street name etc", 78123, "small town");
        System.out.println("===============Address Test =============");
        System.out.println(a);
        Animal an = new Animal(0, "dog food", 4, 10, a);
        System.out.println("===============Animal Test =============");
        System.out.println(an);
        Vehicle v = new Vehicle(0, "ASVJDFJS123", 5, 20, a);
        System.out.println("===============Vehicle Test =============");
        System.out.println(v);
        
    }
    

}