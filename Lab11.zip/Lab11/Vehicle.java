//vehicle class
public class Vehicle {
    private int type;
    private String licensePlate;
    private int age;
    private float weight;
    private Address address;
    public Vehicle()
    {
        licensePlate = "";
        age = 0;
        weight = 0;
        type = -1;
       
    }
    public Vehicle(int type2, String licensePlate2, int age2, float weight2, Address address2)
    {
        type = type2;
        licensePlate = licensePlate2;
        age = age2;
        weight = weight2;
        address = address2;

    }

    // setters and getters for type variable
    void setType(int type2)
    {
        type = type2;

    }
    int getType()
    {
        return type;
    }


    void setLicensePlate(String licensePlate2)
    {
        licensePlate = licensePlate2;
        
    }
    String getLicensePlate()
    {
        return licensePlate;
    }

    void setAge(int age2)
    {
        age = age2;
    }
    int getAge()
    {
        return age;
    }

    void setWeight(float weight2)
    {
        weight = weight2;
    }
    float getWeight()
    {
        return weight;
    }

    void setAddress(Address address2)
    {
        address = address2;
    }
    Address getAddress()
    {
        return address;
    }

    public String toString() {
        return "Animal [type=" + type + ", licensePlate=" + 
        licensePlate + ", age=" + age + ", weight=" + weight + ", address= "+ address + "]";
	}
}