//gamemechanics file
import java.util.*;

public class GameMechanics{
    public static boolean BattleTester(ArrayList <? extends Character> x)
    {
        
        ListIterator<? extends Character> i = x.listIterator();
        while(i.hasNext())
        {
            if(!(i.next() instanceof Hero))
                return false;
        
        }
        return true;
    }
}