import java.util.*;

public class BaseClass implements Comparator<Object> {
    @Override
    public int compare(Object o1, Object o2) {
        float o1Weight = getWeight(o1);
        float o2Weight = getWeight(o2);
        if (o1Weight > o2Weight) return 1;
        else if (o1Weight < o2Weight) return -1;
        return 0;
    }

    private float getWeight(Object o) {
        if (o instanceof Animal) {
            return ((Animal) o).getWeight();
        }
        else if (o instanceof Vehicle) {
            return ((Vehicle) o).getWeight();
        }
        else {
            throw new IllegalArgumentException("Cannot get weight");
        }
    }
}